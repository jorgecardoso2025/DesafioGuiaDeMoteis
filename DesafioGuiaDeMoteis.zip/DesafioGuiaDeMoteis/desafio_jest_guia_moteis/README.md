Este projeto foi criado para testar uma API RESTful utilizando as bibliotecas Supertest e Ajv. Ele inclui testes para as principais operações de CRUD (Create, Read, Update, Delete) e validação de JSON Schema.

Requisitos
Node.js

npm ou yarn

Instalação
Clone o repositório para o seu ambiente local.

bash
git clone https://github.com/seuusuario/seu-repositorio.git
Navegue até o diretório do projeto.

bash
cd seu-repositorio
Instale as dependências do projeto.

bash
npm install
Estrutura do Projeto
A estrutura do projeto está organizada da seguinte forma:

├── tests
│   └── api.test.js      # Testes de API com Supertest
├── schemas
│   └── userSchema.json  # Schema JSON para validação de usuários
├── package.json         # Arquivo de configuração do projeto
└── README.md            # Documentação do projeto
Executando os Testes
Para executar os testes, utilize o comando:

bash
npm test
Descrição dos Testes
Testes de GET /users

Verifica se a rota retorna uma lista de usuários com status 200.

Valida o JSON Schema da resposta.

Testes de POST /users

Cria um novo usuário e verifica se o status é 201.

Tenta criar um usuário sem o campo obrigatório name e espera erro 400.

Testes de Erro 500

Simula um erro 500 no servidor e verifica se o status é 500.

Testes Adicionais

Busca um usuário específico pelo ID com status 200.

Verifica se retorna 404 ao buscar um usuário com ID inexistente.

Atualiza um usuário existente e verifica se o status é 200.

Verifica se retorna 404 ao tentar atualizar um usuário inexistente.

Deleta um usuário existente e verifica se o status é 200 ou 204.

Verifica se retorna 404 ao tentar deletar um usuário inexistente.

Verifica se retorna 404 para rota inexistente.

Contribuição
Contribuições são bem-vindas! Sinta-se à vontade para abrir uma issue ou enviar um pull request.

Licença
Este projeto está licenciado sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

Autor
Feito por Jorge Luiz Cardoso