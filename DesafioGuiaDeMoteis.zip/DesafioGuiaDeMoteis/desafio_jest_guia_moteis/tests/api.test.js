const request = require('supertest');
const Ajv = require('ajv');
const ajvFormats = require('ajv-formats'); // Importando ajv-formats
const fs = require('fs');
const path = require('path');
const baseURL = 'http://localhost:3000';

const ajv = new Ajv();

// Registrar os formatos, incluindo o "email"
ajvFormats(ajv);

// Carregar o schema do arquivo JSON
const userSchema = JSON.parse(fs.readFileSync(path.join(__dirname, '../schemas/userSchema.json'), 'utf-8'));

test('Deve retornar uma lista de usuários com status 200 e validar JSON Schema', async () => {
    const response = await request(baseURL).get('/users');
    const validate = ajv.compile(userSchema);
    const valid = validate(response.body);

    if (!valid) {
        console.error(validate.errors); // Exibe os erros detalhados de validação
    }

    expect(response.status).toBe(200);
    expect(Array.isArray(response.body)).toBeTruthy();
    expect(response.body.length).toBeGreaterThan(0);
    expect(response.body[0]).toHaveProperty('id');
    expect(response.body[0]).toHaveProperty('name');
    expect(response.body[0]).toHaveProperty('email');
    
});

  // Teste de requisição POST com sucesso
  test('Deve criar um novo usuário e retornar status 201', async () => {
    const newUser = {
      name: 'Novo Usuário',
      email: 'novo@email.com',
      username: 'novousuario'
    };

    const response = await request(baseURL)
      .post('/users')
      .send(newUser);

    // Nota: o endpoint pode retornar 201 ou outro status dependendo da implementação
    expect(response.status).toBe(201);
    expect(response.body).toHaveProperty('id');
  });

  // Teste de erro 400 ao enviar um POST sem um campo obrigatório (name)
  test('Deve retornar erro 400 ao tentar criar um usuário sem nome', async () => {
    const invalidUser = {
      email: 'semnome@email.com',
      username: 'semnome'
    };

    const response = await request(baseURL)
      .post('/users')
      .send(invalidUser);

    expect(response.status).toBe(400);
  });

  // Simulação de erro 500 (apenas para exemplificação)
  test('Deve retornar erro 500 ao simular um erro interno do servidor', async () => {
    const response = await request(baseURL).get('/server-error');
    expect(response.status).toBe(500);
  });

  // ----------------- Testes adicionais -----------------

  // Teste GET /users/:id com sucesso
  test('Deve retornar um usuário específico pelo ID com status 200', async () => {
    // Cria um usuário para posteriormente buscá-lo
    const newUser = {
      name: 'Usuário Teste',
      email: 'testeuser@example.com',
      username: 'testeuser'
    };

    const createResponse = await request(baseURL)
      .post('/users')
      .send(newUser);

    expect(createResponse.status).toBe(201);
    const userId = createResponse.body.id;

    // Busca o usuário criado pelo ID
    const response = await request(baseURL).get(`/users/${userId}`);
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('id', userId);
    expect(response.body).toHaveProperty('name', newUser.name);
    expect(response.body).toHaveProperty('email', newUser.email);
  });

  // Teste GET /users/:id para usuário inexistente
  test('Deve retornar 404 ao buscar um usuário com ID inexistente', async () => {
    const nonExistingId = '99999'; // ID improvável de existir
    const response = await request(baseURL).get(`/users/${nonExistingId}`);
    expect(response.status).toBe(404);
  });

  // Teste PUT /users/:id com sucesso (atualização)
  test('Deve atualizar um usuário existente e retornar status 200', async () => {

    const newUser = {
      name: 'Usuário para Atualização',
      email: 'update@example.com',
      username: 'updateuser'
    };

    const createResponse = await request(baseURL)
      .post('/users')
      .send(newUser);

    expect(createResponse.status).toBe(201);
    const userId = createResponse.body.id;

    // Dados atualizados
    const updatedData = {
      name: 'Usuário Atualizado',
      email: 'atualizado@example.com',
      username: 'updateuser'
    };

    const updateResponse = await request(baseURL)
      .put(`/users/${userId}`)
      .send(updatedData);

    expect(updateResponse.status).toBe(200);
    expect(updateResponse.body).toHaveProperty('id', userId);
    expect(updateResponse.body).toHaveProperty('name', updatedData.name);
    expect(updateResponse.body).toHaveProperty('email', updatedData.email);
  });

  test('Deve retornar 404 ao tentar atualizar um usuário inexistente', async () => {
    const nonExistingId = '99999';
    const updatedData = {
      name: 'Nome',
      email: 'email@example.com',
      username: 'user'
    };

    const response = await request(baseURL)
      .put(`/users/${nonExistingId}`)
      .send(updatedData);

    expect(response.status).toBe(404);
  });

  test('Deve deletar um usuário existente e retornar status 200 ou 204', async () => {
  
    const newUser = {
      name: 'Usuário para Deleção',
      email: 'delete@example.com',
      username: 'deleteuser'
    };

    const createResponse = await request(baseURL)
      .post('/users')
      .send(newUser);

    expect(createResponse.status).toBe(201);
    const userId = createResponse.body.id;

    const deleteResponse = await request(baseURL)
      .delete(`/users/${userId}`);

    expect([200, 204]).toContain(deleteResponse.status);
  });

  test('Deve retornar 404 ao tentar deletar um usuário inexistente', async () => {
    const nonExistingId = '99999';
    
    const response = await request(baseURL)
      .delete(`/users/${nonExistingId}`);
    expect(response.status).toBe(404);
  });

  test('Deve retornar 404 para rota inexistente', async () => {
    const response = await request(baseURL)
      .get('/rota-inexistente');
    expect(response.status).toBe(404);
  });


  