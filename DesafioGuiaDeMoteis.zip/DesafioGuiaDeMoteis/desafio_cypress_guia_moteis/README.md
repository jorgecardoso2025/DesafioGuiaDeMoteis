# Testes Automatizados com Cypress

Este projeto contém testes automatizados para validação de formulários de cadastro e login, utilizando a ferramenta **Cypress**.

## 📌 Funcionalidades Testadas

- Cadastro de usuário
- Validação de campos obrigatórios
- Validação de formato de e-mail
- Validação de senha forte
- Testes de login com credenciais corretas e incorretas

## 🚀 Tecnologias Utilizadas

- [Cypress](https://www.cypress.io/): Framework de testes automatizados para aplicações web.
- JavaScript: Linguagem utilizada para escrever os testes.

## 📂 Estrutura do Projeto

```
📁 cypress
 ├── 📁 integration
 │   ├── userRegistrations.cy.js  # Testes de cadastro
 │   ├── loginPage.js              # Testes de login
 ├── 📁 support
 │   ├── commands.js               # Comandos customizados
 │   ├── pages                     # Páginas de suporte
 ├── .gitignore
 ├── README.md                     # Documentação do projeto
```

## 🔧 Como Configurar o Projeto

1. Clone este repositório:
   ```bash
   git clone https://github.com/seu-usuario/nome-do-repo.git
   ```
2. Acesse a pasta do projeto:
   ```bash
   cd nome-do-repo
   ```
3. Instale as dependências:
   ```bash
   npm install
   ```

## ▶️ Como Executar os Testes

Para rodar os testes em modo interativo:
```bash
npx cypress open
```

Para rodar os testes em modo headless:
```bash
npx cypress run
```

## 📜 Autor
Desenvolvido por **[Jorge Luiz Cardoso]**. 

