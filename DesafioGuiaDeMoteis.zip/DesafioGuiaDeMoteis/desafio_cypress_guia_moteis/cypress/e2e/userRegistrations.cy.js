import registrationPage from "../support/pages/userRegistrationPage";
import basePage from "../support/pages/basePage";

describe("Testes do Formulário de Cadastro", function () {
  beforeEach(function () {
    registrationPage.visit();
  });

  it("Deve cadastrar usuário com sucesso", function () {
    registrationPage.fillFormCadastro(
      "João Silva",
      "joao@example.com",
      "joao@example.com",
      "SenhaForte123"
    );
    basePage.submit();
    registrationPage.successMessageShouldBeVisible();
  });

  it("Deve exibir erro ao tentar enviar formulário com campos obrigatórios vazios", function () {
    basePage.submit();
    registrationPage.errorMessagesShouldBeVisible();
  });

  it("Deve exibir erro ao inserir senha fraca", function () {
    registrationPage.fillForm("Maria Souza", "maria@example.com", "maria@example.com", "12345");
    basePage.submit();
    registrationPage.weakPasswordErrorShouldBeVisible();
  });

  it("Deve exibir erro ao e-mails diferentes", function () {
    registrationPage.fillForm("Carlos Lima", "carlos@example.com", "diferente@example.com", "SenhaForte123");
    basePage.submit();
    registrationPage.emailMismatchErrorShouldBeVisible();
  });

  it("Deve exibir erro ao deixar o campo de nome vazio", function () {
    registrationPage.fillForm("", "joao@example.com", "joao@example.com", "SenhaForte123");
    basePage.submit();
    registrationPage.nameFieldErrorShouldBeVisible();
  });

  it("Deve exibir erro ao deixar o campo de e-mail vazio", function () {
    registrationPage.fillForm("João Silva", "", "joao@example.com", "SenhaForte123");
    basePage.submit();
    registrationPage.emailFieldErrorShouldBeVisible();
  });

  it("Deve exibir erro ao inserir e-mail com formato inválido", function () {
    registrationPage.fillForm("João Silva", "joao@com", "joao@com", "SenhaForte123");
    basePage.submit();
    registrationPage.invalidEmailErrorShouldBeVisible();
  });

  it("Deve exibir erro ao deixar o campo de senha vazio", function () {
    registrationPage.fillForm("João Silva", "joao@example.com", "joao@example.com", "");
    basePage.submit();
    registrationPage.passwordFieldErrorShouldBeVisible();
  });

  it("Deve exibir erro se a senha for muito curta", function () {
    registrationPage.fillForm("João Silva", "joao@example.com", "joao@example.com", "123");
    basePage.submit();
    registrationPage.passwordLengthErrorShouldBeVisible();
  });

  it("Deve desabilitar o botão de enviar com dados inválidos", function () {
    registrationPage.fillForm("João Silva", "joao@example.com", "", "12345");
    basePage.submitButtonShouldBeDisabled();
  });

  it("Deve exibir erro se a confirmação de senha não coincidir", function () {
    registrationPage.fillForm("João Silva", "joao@example.com", "joao@example.com", "SenhaForte123", "SenhaErrada123");
    basePage.submit();
    registrationPage.passwordMismatchErrorShouldBeVisible();
  });
});
