import loginPage from "../support/pages/loginPage"
import basePage from "../support/pages/basePage";

describe("Testes da Página de Login", function () {
  beforeEach(function () {
    loginPage.visit();
  });

  it("Deve fazer login com sucesso", function () {
    loginPage.fillFormLogin("joao@example.com", "SenhaForte123");
    basePage.submit();
    loginPage.successMessageShouldBeVisible();
  });

  it("Deve exibir erro ao inserir credenciais inválidas", function () {
    loginPage.fillForm("joao@example.com", "senhaErrada");
    basePage.submit();
    loginPage.errorMessageShouldBeVisible();
  });
});
