class UserRegistrationPage {
  visit() {
    cy.visit("/registro");
  }

  fillForm(name, email, confirmEmail, password, confirmPassword = password) {
    cy.get("#name").clear().type(name);
    cy.get("#email").clear().type(email);
    cy.get("#confirmEmail").clear().type(confirmEmail);
    cy.get("#password").clear().type(password);
    cy.get("#confirmPassword").clear().type(confirmPassword);
  }

  successMessageShouldBeVisible() {
    cy.get(".success-message")
      .should("be.visible")
      .and("include.text", "Cadastro realizado com sucesso"); // Exemplo de mensagem de sucesso
  }

  errorMessagesShouldBeVisible() {
    cy.get(".error-message")
      .should("be.visible")
      .and("include.text", "Por favor, preencha todos os campos obrigatórios");
  }

  weakPasswordErrorShouldBeVisible() {
    cy.get(".error-password-weak")
      .should("be.visible")
      .and("include.text", "A senha deve ter pelo menos 8 caracteres, incluindo letras e números");
  }

  emailMismatchErrorShouldBeVisible() {
    cy.get(".error-email-mismatch")
      .should("be.visible")
      .and("include.text", "Os e-mails não correspondem");
  }

  nameFieldErrorShouldBeVisible() {
    cy.get(".error-name")
      .should("be.visible")
      .and("include.text", "O nome é obrigatório");
  }

  emailFieldErrorShouldBeVisible() {
    cy.get(".error-email")
      .should("be.visible")
      .and("include.text", "O e-mail é obrigatório");
  }

  invalidEmailErrorShouldBeVisible() {
    cy.get(".error-invalid-email")
      .should("be.visible")
      .and("include.text", "Por favor, insira um e-mail válido");
  }

  passwordFieldErrorShouldBeVisible() {
    cy.get(".error-password")
      .should("be.visible")
      .and("include.text", "A senha é obrigatória");
  }

  passwordLengthErrorShouldBeVisible() {
    cy.get(".error-password-length")
      .should("be.visible")
      .and("include.text", "A senha deve ter no mínimo 8 caracteres");
  }

  submitButtonShouldBeDisabled() {
    cy.get("button[type='submit']").should("be.disabled");
  }

  passwordMismatchErrorShouldBeVisible() {
    cy.get(".error-password-mismatch")
      .should("be.visible")
      .and("include.text", "A confirmação de senha não corresponde");
  }
}

export default new UserRegistrationPage();
