class BasePage{    
    submit() {
        cy.get("#submit").click()
      }
}
export default new BasePage()