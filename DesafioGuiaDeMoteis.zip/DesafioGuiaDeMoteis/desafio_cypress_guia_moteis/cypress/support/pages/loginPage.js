class LoginPage {
    visit() {
      cy.visit("/login");
    }
  
    fillFormLogin(email, password) {
      cy.get("#email").type(email);
      cy.get("#password").type(password);
    }
  
    successMessageShouldBeVisible() {
      cy.contains("Login realizado com sucesso").should("be.visible");
    }
  
    errorMessageShouldBeVisible() {
      cy.contains("E-mail ou senha inválidos").should("be.visible");
    }
  }
  
  export default new LoginPage();