import http from 'k6/http';
import { check, sleep } from 'k6';

// URL da API
const BASE_URL = 'http://localhost:3000';

export let options = {
  stages: [
    { duration: '1m', target: 100 }, // Aumentando para 100 usuários em 1 minuto
    { duration: '2m', target: 100 }, // Mantendo 100 usuários por 2 minutos
    { duration: '1m', target: 0 },   // Reduzindo para 0 usuários ao longo de 1 minuto
  ],
};

export default function () {
  // Realizando a requisição GET para o endpoint de usuários
  let resUsers = http.get(`${BASE_URL}/users`);
  check(resUsers, {
    'status é 200': (r) => r.status === 200,
  });

  // Realizando a requisição GET para o endpoint de posts
  let resPosts = http.get(`${BASE_URL}/posts`);
  check(resPosts, {
    'status é 200': (r) => r.status === 200,
  });

  // Pausando por 1 segundo entre as requisições
  sleep(1);
}
