Testes de Carga com K6
Este projeto foi criado para testar a performance e resiliência de uma API RESTful utilizando a ferramenta K6. Ele realiza testes de carga simulando vários usuários simultâneos acessando diferentes endpoints da API.

Requisitos
Node.js

k6 (instalado globalmente)

Instalação
Clone o repositório para o seu ambiente local:

bash
git clone https://github.com/seuusuario/seu-repositorio.git
Navegue até o diretório do projeto:

bash
cd seu-repositorio
Instale as dependências do projeto, se necessário:

bash
npm install
Instale o K6 globalmente, se ainda não estiver instalado:

bash
sudo apt-get install k6
Estrutura do Projeto
A estrutura do projeto está organizada da seguinte forma:

├── load-test
│   └── test.js          # Script de teste de carga com K6
├── package.json         # Arquivo de configuração do projeto
└── README.md            # Documentação do projeto
Executando os Testes
Para executar os testes de carga, utilize o comando:

bash
k6 run load-test/test.js
Descrição dos Testes
Configuração de Carga

Simula a carga aumentando para 100 usuários em 1 minuto.

Mantém 100 usuários por 2 minutos.

Reduz para 0 usuários ao longo de 1 minuto.

Testes GET /users

Realiza a requisição GET para o endpoint /users.

Verifica se o status da resposta é 200.

Testes GET /posts

Realiza a requisição GET para o endpoint /posts.

Verifica se o status da resposta é 200.

Contribuição
Contribuições são bem-vindas! Sinta-se à vontade para abrir uma issue ou enviar um pull request.

Licença
Este projeto está licenciado sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

Autor
Feito por Jorge Luiz Cardoso