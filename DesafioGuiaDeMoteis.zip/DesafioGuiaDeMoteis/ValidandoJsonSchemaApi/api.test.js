// api.test.js
const supertest = require('supertest');
const Ajv = require('ajv');
const userSchema = require('./schemas/userSchema');


const request = supertest('https://jsonplaceholder.typicode.com');
const ajv = new Ajv(); // Instanciando o validador

describe('Testes da API JSONPlaceholder', () => {

  // Testando a requisição GET /users
  it('Deve retornar status 200 para GET /users', async () => {
    const response = await request.get('/users');

    // Verificando o status code
    expect(response.status).toBe(200);

    // Validando a estrutura do JSON
    expect(Array.isArray(response.body)).toBe(true); // Deve retornar um array de usuários
    expect(response.body[0]).toHaveProperty('id');
    expect(response.body[0]).toHaveProperty('name');
    expect(response.body[0]).toHaveProperty('email');
  });

  // Testando a requisição POST /users com dados válidos
  it('Deve retornar status 201 para POST /users', async () => {
    const newUser = {
      name: 'John Doe',
      username: 'johndoe',
      email: 'johndoe@example.com',
    };

    const response = await request.post('/users').send(newUser);

    // Verificando o status code
    expect(response.status).toBe(201);

    // Validando a estrutura da resposta com o JSON Schema
    const validate = ajv.compile(userSchema);
    const valid = validate(response.body);
    expect(valid).toBe(true); // Verifica se a resposta está em conformidade com o JSON Schema
  });

  // Teste para POST inválido (com dados faltando)
  it('Deve retornar status 201 para uma requisição POST inválida', async () => {
    const invalidUser = {}; // Dados faltando

    const response = await request.post('/users').send(invalidUser);

    // Verificando o status code (sempre 201 na API mock)
    expect(response.status).toBe(201);

    // Verificando se o retorno contém apenas o campo id (a API mock sempre retorna um id)
    expect(response.body).toHaveProperty('id');
  });
  it('Deve retornar status 200 para GET /users', async () => {
    const response = await request.get('/users');

    // Verificando o status code
    expect(response.status).toBe(200);

    // Validando a estrutura do JSON
    expect(Array.isArray(response.body)).toBe(true); // Deve retornar um array de usuários
    response.body.forEach(user => {
      const validate = ajv.compile(userSchema);
      const valid = validate(user);
      expect(valid).toBe(true); // Cada usuário deve validar com o schema
    });
  });

  // Testando a requisição POST /users com dados válidos
  it('Deve retornar status 201 para POST /users', async () => {
    const newUser = {
      name: 'John Doe',
      username: 'johndoe',
      email: 'johndoe@example.com',
    };

    const response = await request.post('/users').send(newUser);

    // Verificando o status code
    expect(response.status).toBe(201);

    // Validando a estrutura da resposta com o JSON Schema
    const validate = ajv.compile(userSchema);
    const valid = validate(response.body);
    expect(valid).toBe(true); // Verifica se a resposta está em conformidade com o JSON Schema
  });

  // Teste para POST inválido (com dados faltando)
  it('Deve retornar status 201 para uma requisição POST inválida (com dados faltando)', async () => {
    const invalidUser = {}; // Dados faltando

    const response = await request.post('/users').send(invalidUser);

    // Verificando o status code (sempre 201 na API mock)
    expect(response.status).toBe(201);

    // Verificando se o retorno contém apenas o campo id (a API mock sempre retorna um id)
    expect(response.body).toHaveProperty('id');
    expect(response.body).not.toHaveProperty('name');

  });
  it('Deve retornar status 200 para GET /users', async () => {
    const response = await request.get('/users');
    
    // Verificando o status code
    expect(response.status).toBe(200);
    
    // Validando a estrutura do JSON
    expect(Array.isArray(response.body)).toBe(true); // Deve retornar um array de usuários
    response.body.forEach(user => {
      const validate = ajv.compile(userSchema);
      const valid = validate(user);
      expect(valid).toBe(true); // Cada usuário deve validar com o schema
    });
  });

  // Testando a requisição POST /users com dados válidos
  it('Deve retornar status 201 para POST /users', async () => {
    const newUser = {
      name: 'John Doe',
      username: 'johndoe',
      email: 'johndoe@example.com',
    };

    const response = await request.post('/users').send(newUser);

    // Verificando o status code
    expect(response.status).toBe(201);
    
    // Validando a estrutura da resposta com o JSON Schema
    const validate = ajv.compile(userSchema);
    const valid = validate(response.body);
    expect(valid).toBe(true); // Verifica se a resposta está em conformidade com o JSON Schema
  });

  // Teste para POST inválido (com dados faltando)
  it('Deve retornar status 201 para uma requisição POST inválida (com dados faltando)', async () => {
    const invalidUser = {}; // Dados faltando

    const response = await request.post('/users').send(invalidUser);

    // Verificando o status code (sempre 201 na API mock)
    expect(response.status).toBe(201);
    
    // Verificando se o retorno contém apenas o campo id (a API mock sempre retorna um id)
    expect(response.body).toHaveProperty('id');
    expect(response.body).not.toHaveProperty('name');
  });

  // Testando a requisição GET /users/{id}
  it('Deve retornar status 200 para GET /users/{id}', async () => {
    const userId = 1; // ID de um usuário válido
    const response = await request.get(`/users/${userId}`);
    
    // Verificando o status code
    expect(response.status).toBe(200);
    
    // Validando a estrutura do JSON
    const validate = ajv.compile(userSchema);
    const valid = validate(response.body);
    expect(valid).toBe(true); // O usuário retornado deve estar conforme o schema
  });

  // Testando erro 404 para GET /users/{id} (usuário inexistente)
  it('Deve retornar status 404 para GET /users/{id} com usuário inexistente', async () => {
    const userId = 9999; // ID de um usuário que não existe
    const response = await request.get(`/users/${userId}`);
    
    // Verificando o status code
    expect(response.status).toBe(404);
  });
});

