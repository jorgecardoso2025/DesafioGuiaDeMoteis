# Testes da API JSONPlaceholder

Este projeto contém uma suíte de testes para a API **JSONPlaceholder**, uma API REST falsa utilizada para simular operações com dados de usuários. Os testes são realizados utilizando as bibliotecas **Supertest** para fazer as requisições HTTP e **AJV** para validar a estrutura dos dados com base em um JSON Schema.

## Tecnologias Utilizadas

- **Supertest**: Biblioteca para realizar requisições HTTP em testes.
- **AJV**: Validador de JSON Schema.
- **Jest**: Framework de testes para execução automatizada dos testes.

## Requisitos

Antes de rodar os testes, você precisa ter o **Node.js** instalado na sua máquina. Caso não tenha, você pode baixar e instalar a versão mais recente do Node.js [aqui](https://nodejs.org/).

Além disso, você precisará instalar as dependências do projeto. Execute o seguinte comando para instalar as dependências:

```bash
npm install

Estrutura do Projeto
/schemas/userSchema.js
/tests
package.json

Como Rodar os Testes
Para rodar os testes use o comando

npm test

Casos de teste

OBTER /usuários 
POST /users (dados válidos)
POST /users (dados inválidos) 
OBTER /usuários/{id}
GET /users/{id} (usuário inexistente)